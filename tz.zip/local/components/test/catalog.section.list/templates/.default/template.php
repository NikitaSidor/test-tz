<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
use Bitrix\Main\Localization\Loc;
?>

<h2>4 задание вывод товаров из раздела</h2>

<? if (!empty($arResult["ITEMS"])): ?>
    <ul>
        <? foreach($arResult["ITEMS"] as $arItem): ?>
            <li>
                <?=Loc::getMessage("PRODUCT_ID")?>: <?=$arItem["ID"]?>, <?=Loc::getMessage("PRODUCT_NAME")?>: <?=$arItem["NAME"]?>
            </li>
        <? endforeach; ?>
    </ul>
<? else: ?>
    <p><?=Loc::getMessage("ITEMS_NOT_FOUND")?></p>
<? endif; ?>