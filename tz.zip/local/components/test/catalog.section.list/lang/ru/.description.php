<?
$MESS["MODULE_IBLOCK_NOT_INSTALLED"] = "Модуль iblock не установлен";
$MESS["MY_COMPONENT_NAME"] = "Мой компонент для списка товаров";
$MESS["MY_COMPONENT_DESCRIPTION"] = "Выводит список товаров из раздела";
$MESS["MY_COMPONENT_PATH"] = "Мои компоненты";
$MESS["IBLOCK_ID"] = "ID инфоблока";
$MESS["SECTION_ID"] = "ID раздела";
$MESS["INVALID_PARAMETERS"] = "Некорректные параметры";
$MESS["ITEMS_NOT_FOUND"] = "Товары не найдены";
$MESS["PRODUCT_ID"] = "ID товара";
$MESS["PRODUCT_NAME"] = "Название товара";
?>