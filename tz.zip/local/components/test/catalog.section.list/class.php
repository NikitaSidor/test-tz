<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Loader;
use Bitrix\Iblock\ElementTable;
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

class MyCustomCatalogListComponent extends CBitrixComponent
{

    public function executeComponent()
    {

        // Проверяем, что модуль catalog установлен
        if (!Loader::includeModule("iblock")) {
            ShowError(Loc::getMessage("MODULE_IBLOCK_NOT_INSTALLED"));
            return;
        }
        $iblockId = intval($this->arParams["IBLOCK_ID"]);
        $sectionId = intval($this->arParams["SECTION_ID"]);

        if($iblockId <= 0 || $sectionId <= 0){
            ShowError(Loc::getMessage("INVALID_PARAMETERS"));
            return;
        }

        $arFilter = array(
            'IBLOCK_ID' => $iblockId,
            'IBLOCK_SECTION_ID' => $sectionId,
            'ACTIVE' => 'Y',
        );

        $rsItems = ElementTable::getList(array(
            'select' => array('ID','NAME'),
            'filter' => $arFilter,
        ));


        $arItems = array();
        while($arItem = $rsItems->fetch()){
            $arItems[] = $arItem;
        }

        if(empty($arItems)){
            ShowError(Loc::getMessage("ITEMS_NOT_FOUND"));
            return;
        }

        $this->arResult["ITEMS"] = $arItems;
        $this->includeComponentTemplate();


    }
}

?>