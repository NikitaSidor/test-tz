<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

$arComponentParameters = array(
    "PARAMETERS" => array(
        "IBLOCK_ID" => array(
            "PARENT" => "BASE",
            "NAME" => Loc::getMessage("IBLOCK_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
        ),
        "SECTION_ID" => array(
            "PARENT" => "BASE",
            "NAME" => Loc::getMessage("SECTION_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
        ),
    ),
);
?>