<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\UserTable;
use Bitrix\Main\GroupTable;
use Bitrix\Main\UserGroupTable;
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

class MyCustomUsersComponent extends CBitrixComponent
{

    public function executeComponent()
    {
        // Подключаем модуль main
        if (!CModule::IncludeModule("main")) {
            ShowError(Loc::getMessage("MODULE_MAIN_NOT_INSTALLED"));
            return;
        }

        // Название группы


        // Сохраняем результат в arResult
        $this->arResult = $this->getTheAdminUsers();

        // Если пользователей нет, выводим сообщение
        if (empty($this->arResult)) {
            ShowError('Нет пользователей в группе "Администраторы"');
        }

        $this->includeComponentTemplate();
        return $this->arResult;
    }

    private function getTheAdminUsers() {
        $adminGroupName = 'Администраторы';

        // Получаем ID группы "Администраторы"
        $group = GroupTable::getList([
            'filter' => ['NAME' => $adminGroupName],
            'select' => ['ID']
        ]);

        $adminGroupId = null;

        if ($arGroup = $group->fetch()) {
            $adminGroupId = $arGroup['ID'];
        } else {
            // Если группа не найдена, выводим ошибку
            ShowError(Loc::getMessage("GROUP_NOT_FOUND", ["#GROUP_NAME#" => $adminGroupName]));
            return;
        }

        // Получаем ID пользователей, принадлежащих этой группе
        $userGroupList = UserGroupTable::getList([
            'filter' => ['GROUP_ID' => $adminGroupId],
            'select' => ['USER_ID']
        ]);

        $userIds = [];
        while ($userGroup = $userGroupList->fetch()) {
            $userIds[] = $userGroup['USER_ID'];
        }

        // Получаем данные пользователей
        $users = [];
        if (!empty($userIds)) {
            $userResult = UserTable::getList([
                'filter' => ['ID' => $userIds],
                'select' => ['LOGIN', 'EMAIL', 'NAME', 'LAST_NAME']
            ]);

            while ($user = $userResult->fetch()) {
                $users[] = $user;
            }
        }

        return $users;
    }
};

?>