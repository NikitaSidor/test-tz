<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
use Bitrix\Main\Localization\Loc;
?>

<h2>3 задание вывод администраторов</h2>
<? if (!empty($arResult)): ?>
    <ul>
        <? foreach($arResult as $arUser): ?>
            <li>
                <?=Loc::getMessage("LOGIN")?>: <?=$arUser["LOGIN"]?>, <?=Loc::getMessage("EMAIL")?>: <?=$arUser["EMAIL"]?>, <?=Loc::getMessage("NAME")?>: <?=$arUser["NAME"]?>, <?=Loc::getMessage("LAST_NAME")?>: <?=$arUser["LAST_NAME"]?>
            </li>
        <? endforeach; ?>
    </ul>
<? else: ?>
    <p><?=Loc::getMessage("USERS_NOT_FOUND")?></p>
<? endif; ?>