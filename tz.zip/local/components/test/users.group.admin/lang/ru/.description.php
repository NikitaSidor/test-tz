<?
$MESS["MODULE_MAIN_NOT_INSTALLED"] = "Модуль main не установлен";
$MESS["USERS_NOT_FOUND"] = "Нет пользователей в группе 'Администратор'";
$MESS["LOGIN"] = "Логин";
$MESS["EMAIL"] = "Email";
$MESS["NAME"] = "Имя";
$MESS["LAST_NAME"] = "Фамилия";
$MESS["GROUP_NOT_FOUND"] = "Группа '#GROUP_NAME#' не найдена";
$MESS["MY_COMPONENT_NAME"] = "Пользователи из группы Администратор";
$MESS["MY_COMPONENT_DESCRIPTION"] = "Выводит список пользователей из группы Администратор";
$MESS["MY_COMPONENT_PATH"] = "Мои компоненты";
?>