<?
$sSectionName = "test";
$arDirProperties = Array(

);
?>